"""Build only review sheets, requested size/circle exports and catalog metadata.
Original generated artwork and real screenshots are never edited.
Run with bundled Python/Pillow; all output stays within this brand-kit.
"""
from pathlib import Path
import json, hashlib, shutil
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
registry = json.loads((ROOT / 'prompts-final.json').read_text(encoding='utf-8'))
BG = '#0E1419'
INK = '#F4FFFF'
font_path = 'C:/Windows/Fonts/arial.ttf'
def font(size):
    return ImageFont.truetype(font_path, size)
def thumb(path, size):
    im = Image.open(path).convert('RGBA')
    im.thumbnail(size, Image.Resampling.LANCZOS)
    return im
def label(draw, xy, text, size=20, color=INK):
    draw.text(xy, text, font=font(size), fill=color)
def place(canvas, path, box):
    x,y,w,h = box
    im = thumb(path, (w,h))
    canvas.paste(im, (x+(w-im.width)//2,y+(h-im.height)//2), im)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

uses = {
 'app-icon':'Концепт иконки приложения; выбор для последующего внедрения',
 'bot-avatar':'Аватар Telegram-бота; приветствие',
 'player-avatar':'Базовая аватарка игрока; подмигивание',
 'hero-ready':'Приветствие, начало попытки, профиль — иллюстрация от 96 px',
 'hero-delighted':'Радостный результат; от 96 px',
 'hero-focused':'Подсказка управления, концентрация; от 96 px',
 'hero-resting':'Отдых/отсутствие жизней; от 96 px',
 'lives':'Крупная карточка жизней; не энергия',
 'crystals':'Крупная карточка кристаллов; кубическая игровая валюта',
 'jump':'Крупная иллюстрация прыжка; от 96 px',
 'helmet':'Крупная иллюстрация аренды шлема; от 96 px',
 'reward':'Награда/личный рекорд; без выдуманных чисел',
 'plus':'Иллюстрация Plus; текст условий и преимуществ отдельно',
 'start-banner':'Стартовый баннер; свободная область слева под живой текст',
 'promo-banner':'Промо аркады; свободная область слева под живой текст',
 'concept-board':'Сгенерированный обзор направления; не точный лист экспортируемых файлов',
}
manifest = {'version':'2026-10-06-v1', 'status':'catalog for selection; not integrated or published',
 'palette':{'mint':'#3DDC97','mint_highlight':'#86FFD3','turquoise':'#179CB0','cyan':'#7EE0FF','yellow':'#FFD54A','coral':'#FF5A5F','background':BG,'ink':'#122C38','eye_white':'#F4FFFF','blush':'#FF89AD'},
 'generator':'built-in image_gen', 'assets':[], 'screenshots':[]}
for s in registry['assets']:
    path=ROOT/s['file']
    im=Image.open(path)
    alpha=im.getchannel('A').getextrema() if 'A' in im.getbands() else (255,255)
    transparent=alpha[0]<255
    assert transparent == s['transparent_background'], (s['id'],alpha)
    entry={**s,'size':list(im.size),'mode':im.mode,'alpha_range':list(alpha),'sha256':digest(path),'recommended_use':uses[s['id']],
      'background':'transparent alpha' if transparent else 'opaque dark navy',
      'crop_rule':'Contain entire artwork; preserve padding and alpha. No face or object cropping.' if transparent else ('Center square or circle mask; face must stay visible; use supplied 32/48/96 tests.' if 'avatar' in s['id'] or s['id']=='app-icon' else 'Preserve original 3:2; use contain. Do not stretch; do not center-crop to mobile portrait.'),
      'visual_review':'Reviewed 06.10.2026: silhouette, consistent palette/material/character, intended use; alpha on light/dark. Avatars also 32/48/96 square/circle.'}
    manifest['assets'].append(entry)
    # Requested preview assets only: scaling and circular masking, no creative edits.
    if s['id'] in ['app-icon','bot-avatar','player-avatar']:
        for size in [32,48,96,512,640,1024]:
            small=im.convert('RGBA').resize((size,size),Image.Resampling.LANCZOS)
            small.save(ROOT/'previews'/f'{s["id"]}-{size}.png')
            mask=Image.new('L',(size,size),0)
            ImageDraw.Draw(mask).ellipse((0,0,size-1,size-1),fill=255)
            circle=small.copy(); circle.putalpha(mask)
            circle.save(ROOT/'previews'/f'{s["id"]}-{size}-circle.png')
    elif transparent:
        thumb(path,(512,512)).save(ROOT/'previews'/f'{s["id"]}-512.png')

canvas=Image.new('RGB',(1600,1650),BG)
d=ImageDraw.Draw(canvas)
label(d,(48,32),'UNTOUCH / BRAND KIT',44)
label(d,(48,92),'06.10.2026  •  каталог для выбора  •  мягкая объёмная графика',22,'#7EE0FF')
for i,s in enumerate(registry['assets'][:13]):
    col=i%5; row=i//5
    x=40+col*310; y=150+row*325
    d.rounded_rectangle((x,y,x+290,y+300),20,fill='#182228')
    place(canvas,ROOT/s['file'],(x+12,y+8,266,248))
    label(d,(x+18,y+263),s['id'],22)
for i,s in enumerate(registry['assets'][13:15]):
    x=40+i*775
    place(canvas,ROOT/s['file'],(x,1150,735,430))
    label(d,(x,1598),s['id']+'  /  1536×1024',22)
canvas.save(ROOT/'previews'/'catalog-overview.png')

canvas=Image.new('RGB',(1100,670),BG); d=ImageDraw.Draw(canvas)
label(d,(30,22),'ICON CHECK / native pixels',32)
label(d,(30,66),'Квадрат и круг — 32 / 48 / 96 px. Без увеличения.',20,'#7EE0FF')
for row,id in enumerate(['app-icon','bot-avatar','player-avatar']):
    y=135+row*165
    label(d,(30,y+35),id,22)
    for col,size in enumerate([32,48,96]):
        x=265+col*265
        label(d,(x,y-5),str(size)+' px',18)
        for offset,suffix in [(0,''),(115,'-circle')]:
            im=Image.open(ROOT/'previews'/f'{id}-{size}{suffix}.png').convert('RGBA')
            canvas.paste(im,(x+offset+(96-size)//2,y+28+(96-size)//2),im)
canvas.save(ROOT/'previews'/'icon-size-check.png')

canvas=Image.new('RGB',(1600,1350),'#E9F0F3');d=ImageDraw.Draw(canvas)
label(d,(30,22),'ALPHA CHECK / light and dark',32,'#122C38')
for i,s in enumerate([a for a in registry['assets'] if a['transparent_background']]):
    for dark in [False,True]:
        col=i%5;row=(i//5)*2+int(dark);x=20+col*315;y=95+row*305
        d.rounded_rectangle((x,y,x+295,y+280),12,fill='#0E1419' if dark else '#FFFFFF')
        place(canvas,ROOT/s['file'],(x+15,y+8,265,230))
        label(d,(x+14,y+247),s['id'],18,INK if dark else '#122C38')
canvas.save(ROOT/'previews'/'alpha-review.png')

canvas=Image.new('RGB',(1400,1450),BG);d=ImageDraw.Draw(canvas)
label(d,(48,32),'UNTOUCH / REAL SCREENS',38)
label(d,(48,88),'Android 1.0.32+33  •  Pixel 7 / API36 emulator  •  06.10.2026',22,'#7EE0FF')
for i,name in enumerate(['android-1.0.32-main.png','android-1.0.32-profile.png']):
    p=ROOT/'screenshots'/name
    assert digest(p)==digest(ROOT.parent.parent/'docs'/'release-evidence'/name)
    x=70+i*680
    place(canvas,p,(x,150,550,1222))
    label(d,(x,1382),'Игра / исходный экран' if i==0 else 'Профиль / исходный экран',22)
    manifest['screenshots'].append({'file':'screenshots/'+name,'source':'docs/release-evidence/'+name,'sha256':digest(p),'size':list(Image.open(p).size),'capture':'Android emulator Pixel 7/API36; debug APK 1.0.32+33','altered':False,'use':'review; store publication not approved; Google connection explicitly unavailable'})
canvas.save(ROOT/'previews'/'screenshots-overview.png')

manifest['variant']={**registry['variant'],'size':list(Image.open(ROOT/registry['variant']['file']).size),'sha256':digest(ROOT/registry['variant']['file'])}
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'generated_assets':len(manifest['assets']),'transparent_assets':sum(a['transparent_background'] for a in manifest['assets']),'screenshots':len(manifest['screenshots']),'previews':len(list((ROOT/'previews').glob('*.png')))},ensure_ascii=False))
